<?php $__env->startSection('dashboard'); ?>
    <div id="accordion" class=" justify-content-end">
        <?php $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card " id="card<?php echo e($reserva->id); ?>">
            <div class="card-header bg-danger" id="heading<?php echo e($reserva->id); ?>">
                <div class="row"  data-toggle="collapse" data-target="#collapse<?php echo e($reserva->id); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($reserva->id); ?>">
                    <div class="col-6 text-left">
                        <h6><?php echo e($reserva->telefono); ?></h6>
                    </div>
                    <div class="col-6 text-right">
                        <?php echo e($reserva->fecha); ?>

                    </div>
                </div>
            </div>
            <div id="collapse<?php echo e($reserva->id); ?>" class="collapse show" aria-labelledby="heading<?php echo e($reserva->id); ?>" data-parent="#card">
                <div class="card-body">
                    <h5>CODIGO: <?php echo e($reserva->codigo); ?></h5>
                    <p><b><?php echo e($reserva->cantidad); ?>&nbsp;</b>
                        <?php if($reserva->cantidad == 1): ?>
                            persona
                        <?php else: ?>
                            personas
                        <?php endif; ?>
                        &nbsp;mesa:<b>&nbsp;<?php echo e($reserva->id_mesaFK); ?></b>
                    </p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\test\resources\views/reservas.blade.php ENDPATH**/ ?>